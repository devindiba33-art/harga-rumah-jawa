# Range Harga Rumah Pulau Jawa

Dashboard statis dari dataset 1.000 properti di 6 provinsi Pulau Jawa.

- `index.html` : halaman dashboard (tanpa dependensi, satu file)

## Hosting gratis dengan HTTPS (GitHub Pages)

1. Buat repo baru di GitHub, lalu unggah `index.html` dan `README.md`.
2. Buka **Settings > Pages**, pilih **Deploy from a branch**, branch `main`, folder `/ (root)`, lalu **Save**.
3. Tunggu 1-2 menit. Situs tersedia di `https://<username>.github.io/<nama-repo>/` (HTTPS aktif otomatis).
